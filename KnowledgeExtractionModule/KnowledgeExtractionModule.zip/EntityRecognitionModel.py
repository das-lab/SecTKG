from typing import Dict, Any
from tensorflow import keras
from kashgari.layers import L, KConditionalRandomField
from kashgari.tasks.labeling.abc_model import ABCLabelingModel
from kashgari.embeddings import BertEmbedding
import kashgari
from tensorflow.python import keras
from kashgari.callbacks import EvalCallBack
from func import load_data


class BiLSTM_ATT_CRF_Model(ABCLabelingModel):

    @classmethod
    def default_hyper_parameters(cls) -> Dict[str, Dict[str, Any]]:
        return {
            'layer_blstm': {
                'units': 256,
                'return_sequences': True
            },
            'layer_dropout': {
                'rate': 0.4
            },
            'layer_time_distributed': {},
            'layer_activation': {
                'activation': 'softmax'
            }
        }

    def build_model_arc(self) -> None:
        output_dim = self.label_processor.vocab_size

        config = self.hyper_parameters
        embed_model = self.embedding.embed_model

        crf = KConditionalRandomField()

        # Define your layers
        layer_blstm = L.Bidirectional(L.LSTM(**config['layer_blstm']),
                                       name='layer_blstm')

        layer_dropout = L.Dropout(**config['layer_dropout'],
                                  name='layer_dropout')

        layer_time_distributed = L.TimeDistributed(L.Dense(output_dim,
                                                           **config['layer_time_distributed']),
                                                   name='layer_time_distributed')
        layer_activation = L.Activation(**config['layer_activation'])

        # Define tensor flow
        query_embeddings = embed_model.output
        value_embeddings = embed_model.output

        # tensor = layer_blstm(embed_model.output)
        query_seq_encoding = layer_blstm(query_embeddings)
        value_seq_encoding = layer_blstm(value_embeddings)
        # print(tf_utils.get_shapes(query_seq_encoding))
        query_value_attention_seq = L.Attention()(
            [query_seq_encoding, value_seq_encoding])
        
        input_layer = L.Concatenate(axis=-1)([query_seq_encoding, query_value_attention_seq])
        tensor = layer_dropout(input_layer)

        tensor = L.BatchNormalization()(tensor) 
        tensor = L.Dense(output_dim, **config['layer_time_distributed'])(tensor)

        tensor = crf(tensor)

        self.tf_model = keras.Model(embed_model.inputs, tensor)
        self.crf_layer = crf

    def compile_model(self,
                      loss: Any = None,
                      optimizer: Any = None,
                      metrics: Any = None,
                      **kwargs: Any) -> None:
        if loss is None:
            loss = self.crf_layer.loss
        if metrics is None:
            metrics = [self.crf_layer.accuracy]
        super(BiLSTM_ATT_CRF_Model, self).compile_model(loss=loss,
                                                    optimizer=optimizer,
                                                    metrics=metrics,
                                                    **kwargs)


def ner_model():
    
    bert_embed = BertEmbedding('../data/secBERT', task=kashgari.tasks.labeling)
    model = BiLSTM_ATT_CRF_Model(bert_embed)

    labels, sentences = load_data('../data/ner_label.csv')

    VALIDATION_SPLIT = 0.8
    nb_validation_samples = int(VALIDATION_SPLIT * len(labels))

    train_x, train_y = sentences[:nb_validation_samples], list(labels[:nb_validation_samples])
    validate_x, validate_y = sentences[nb_validation_samples:], list(labels[nb_validation_samples:])

    tf_board_callback = keras.callbacks.TensorBoard(log_dir='logs', update_freq=1000)
    eval_callback = EvalCallBack(kash_model=model,
                                 x_data=validate_x,
                                 y_data=validate_y,
                                 step=1)
    model.fit(train_x, train_y, validate_x, validate_y, batch_size=64, epochs=30, callbacks=[eval_callback, tf_board_callback])
    model.evaluate(validate_x, validate_y)
    model.save('./bert_model')

if __name__ == '__main__':
    ner_model()