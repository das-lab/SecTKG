from tensorflow.keras.layers import (Input, Embedding, Conv1D, concatenate,
                                     MaxPooling1D, Flatten, Dropout, Activation, GlobalMaxPooling1D,
                                     BatchNormalization,
                                     Dense)
from tensorflow.keras.models import Model
from keras.regularizers import l2
from tensorflow.keras.preprocessing import text
from tensorflow.keras.preprocessing import sequence
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.utils import to_categorical
from sklearn.metrics import classification_report

from func import load_cons_data, load_type_data, load_matrix, l2_loss, metric_precision, metric_recall, metric_F1score


class TextCNN:
    def __init__(self, seq_length, embedding_weights, kernel_sizes, kernel_filters,
                 activation, pool_size, dropout_rate, label_size, optimizer):
        """
        :param seq_length: sequence length (int)
        :param embedding_weights: embedding weights matrix (array)
        :param kernel_sizes: kernel sizes (list)
        :param kernel_filters: kernel channels/filters (list)
        :param activation: activation （string）
        :param pool_size: pooling size (int)
        :param dropout_rate:  dropout rate (float)
        :param label_size: label size (int)
        :param optimizer: optimizer （string）
        """
        self.seq_length = seq_length
        self.embedding_weights = embedding_weights
        self.kernel_sizes = kernel_sizes
        self.kernel_filters = kernel_filters
        self.activation = activation
        self.pool_size = pool_size
        self.dropout_rate = dropout_rate
        self.label_size = label_size
        self.optimizer = optimizer

    def build(self):
        inp = Input(shape=(self.seq_length,), dtype='int32')
        embedding = Embedding(
            name="embedding",
            input_dim=self.embedding_weights.shape[0],
            weights=[self.embedding_weights],
            output_dim=self.embedding_weights.shape[1],
            trainable=False
        )
        embed = embedding(inp)
        cnn_feat = []
        for s, f in zip(self.kernel_sizes, self.kernel_filters):
            cnn = Conv1D(filters=f,
                         kernel_size=s,
                         strides=1,
                         padding='same',
                         activation=self.activation
                         )(embed)
            cnn = GlobalMaxPooling1D(pool_size=self.pool_size)(cnn)
            cnn_feat.append(cnn)
        fc = concatenate(cnn_feat, axis=-1)
        fc = Flatten()(fc)
        fc = Dropout(rate=self.dropout_rate)(fc)

        fc = Dense(256)(fc)
        fc = BatchNormalization()(fc)
        fc = Activation(activation=self.activation)(fc)
        fc = Dropout(rate=self.dropout_rate)(fc)

        out = Dense(self.label_size, activation="softmax", kernel_regularizer=l2(0.01))(fc)
        model = Model(inputs=inp, outputs=out)

        return model


def para_level_model(type, MAXLEN=200, epochs=30):
    if type == 'consequence':
        labels, texts = load_cons_data('../data/cons_en_full.csv')
        label_size = 4
    else:
        labels, texts = load_type_data('../data/type_en_full.csv')
        label_size = 2

    tokenizer = text.Tokenizer(num_words=None, lower=True)
    tokenizer.fit_on_texts(texts)
    nb_validation_samples = int(0.2 * labels.shape[0])

    word_index = tokenizer.word_index
    MAX_NB_WORDS = 200
    EMBEDDING_DIM = 300
    embedding_matrix = load_matrix(word_index, MAX_NB_WORDS, EMBEDDING_DIM)

    train_ = sequence.pad_sequences(tokenizer.texts_to_sequences(texts[:-nb_validation_samples]), maxlen=MAXLEN)
    test_ = sequence.pad_sequences(tokenizer.texts_to_sequences(texts[-nb_validation_samples:]), maxlen=MAXLEN)

    lb = LabelEncoder()
    train_label = lb.fit_transform(labels[:-nb_validation_samples].values)
    train_label = to_categorical(train_label)
    dev_label = lb.fit_transform(labels[-nb_validation_samples:].values)
    dev_label = to_categorical(dev_label)

    model = TextCNN(seq_length=MAXLEN, embedding_weights=embedding_matrix,
                    kernel_sizes=[3, 3, 3], kernel_filters=[256, 128, 64], pool_size=80, activation='relu',
                    dropout_rate=0.4, label_size=label_size,
                    optimizer='adam').build()

    model.compile(loss=l2_loss,  # 'categorical_crossentropy',
                  optimizer='adam', metrics=['accuracy', metric_precision, metric_recall, metric_F1score])
    model.summary()
    model.fit(train_, train_label, validation_data=(test_, dev_label), epochs=epochs)

    # model.evaluate()
    # y_predicts = model.predict(test_,batch_size=64,verbose=1)
    # test_para = sequence.pad_sequences(tokenizer.texts_to_sequences(test_), maxlen=MAXLEN)
    # y_predict = np.argmax(model.predict(train_), axis=1) #model.predict_classes(test_,batch_size=64,verbose=1)
    # report = classification_report(y_l,y_predict,digits=4)
    # print(report)


if __name__ == '__main__':
    para_level_model('consequence', 200, 30)
