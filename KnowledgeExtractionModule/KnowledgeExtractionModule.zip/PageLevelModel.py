from kashgari.embeddings import WordEmbedding
from kashgari.tokenizers import BertTokenizer
from kashgari.processors import ClassificationProcessor
from kashgari.tasks.classification import ABCClassificationModel
import kashgari
import os
from typing import Dict, Any
from kashgari.layers import L
from tensorflow import keras
from func import load_data, metric_precision, metric_recall, metric_F1score


class BiLSTMAttModel(ABCClassificationModel):

    @classmethod
    def default_hyper_parameters(cls) -> Dict[str, Dict[str, Any]]:
        return {
            'layer_blstm': {
                'units': 128,
                'return_sequences': False
            },
            'layer_dropout': {
                'rate': 0.4
            },
            'layer_output': {
            }
        }

    def build_model_arc(self) -> None:
        output_dim = self.label_processor.vocab_size

        config = self.hyper_parameters
        embed_model = self.embedding.embed_model

        # Define layers
        layer_blstm = L.Bidirectional(L.LSTM(**config['layer_blstm']),
                                      name='layer_blstm')

        layer_dropout = L.Dropout(**config['layer_dropout'],
                                  name='layer_dropout')

        layer_output = L.TimeDistributed(L.Dense(output_dim,
                                                 **config['layer_output']),
                                         name='layer_output')
        # layer_activation = L.Activation(**config['layer_activation'])

        # Define tensor flow
        query_embeddings = embed_model.output
        value_embeddings = embed_model.output

        # tensor = layer_blstm(embed_model.output)
        query_seq_encoding = layer_blstm(query_embeddings)
        value_seq_encoding = layer_blstm(value_embeddings)

        query_value_attention_seq = L.Attention()(
            [query_seq_encoding, value_seq_encoding])
        # query_encoding = L.GlobalMaxPool1D()(query_seq_encoding)
        # query_value_attention = L.GlobalMaxPool1D()(query_value_attention_seq)
        input_layer = L.Concatenate(axis=-1)([query_seq_encoding, query_value_attention_seq])
        tensor = layer_dropout(input_layer)
        tensor = L.BatchNormalization()(tensor)
        output = L.Dense(output_dim, **config['layer_output'])(tensor)
        output = self._activation_layer()(output)

        self.tf_model: keras.Model = keras.Model(embed_model.inputs, output)

    def compile_model(self,
                      loss: Any = None,
                      optimizer: Any = None,
                      metrics: Any = None,
                      **kwargs: Any) -> None:
        if loss is None:
            loss = self.crf_layer.loss
        if metrics is None:
            metrics = [self.crf_layer.accuracy]
        super(BiLSTMAttModel, self).compile_model(loss=loss,
                                                    optimizer=optimizer,
                                                    metrics=metrics,
                                                    **kwargs)


def page_level_model():
    labels, sentences = load_data('../data/phase_en_full.csv')
    processor = ClassificationProcessor(multi_label=True)

    word2vec_embedding = WordEmbedding(w2v_path="../data/sec_w2v.bin",
                                       task=kashgari.tasks.classification,
                                       w2v_kwargs={'binary': True, 'unicode_errors': 'ignore'},
                                       sequence_length='auto')

    VALIDATION_SPLIT = 0.8
    nb_validation_samples = int(VALIDATION_SPLIT * len(labels))

    train_x, train_y = sentences[:nb_validation_samples], list(labels[:nb_validation_samples])
    validate_x, validate_y = sentences[nb_validation_samples:], list(labels[nb_validation_samples:])

    model = BiLSTMAttModel(word2vec_embedding, label_processor=processor, sequence_length=2000, multi_label=True)
    model.build_model(train_x, train_y)
    model.compile_model(loss='categorical_crossentropy', optimizer='adam',
                        metrics=['accuracy', metric_precision, metric_recall, metric_F1score])

    model.fit(
        train_x, train_y,
        validate_x, validate_y,
        epochs=30,
        batch_size=64
    )


if __name__ == '__main__':
    page_level_model()

    # save model
    # model.save('../model')
